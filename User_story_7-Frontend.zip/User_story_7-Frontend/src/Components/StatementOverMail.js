import React, { useState } from 'react';

// Simple page to request e-statement over mail
function StatementOverMail({ ctx, onBack, onSubmit }) {
  // Ensure hooks always run; fall back to empty values if ctx not provided yet
  const safeCtx = ctx || {};
  const [accountNumber] = useState(safeCtx.account?.number || '');
  const [fromDate, setFromDate] = useState(safeCtx.fromDate || '');
  const [toDate, setToDate] = useState(safeCtx.toDate || '');
  const [email, setEmail] = useState(safeCtx.email || '');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ accountNumber, fromDate, toDate, email });
  };

  if (!ctx) {
    return <div className="transactions" style={{ padding: '1rem' }}>Loading statement form...</div>;
  }

  return (
    <div className="transactions" style={{ padding: '15px' }}>
      <h2>E-Statement Over Mail</h2>
      <form onSubmit={handleSubmit} className="statement-mail-form">
        <div className="form-row">
          <label>Account Number*</label>
          <select value={accountNumber} disabled>
            <option>{accountNumber}</option>
          </select>
        </div>
        <div className="form-row">
          <label>Transaction Date from*</label>
          <input type="date" value={fromDate} onChange={e => setFromDate(e.target.value)} />
          <span style={{ padding: '0 4px' }}>to*</span>
          <input type="date" value={toDate} onChange={e => setToDate(e.target.value)} />
        </div>
        <div className="form-row">
          <label>Email ID*</label>
          <input type="email" value={email} onChange={e => setEmail(e.target.value)} />
          <button type="button" className="link-btn">Update E-mail ID</button>
        </div>
        <div className="form-actions">
          <button type="button" onClick={onBack}>Back</button>
          <button type="submit">Submit</button>
        </div>
      </form>
    </div>
  );
}

export default StatementOverMail;
