import AppContent from "./AppContent";
import useAppState from "./hooks/useAppState";

function App(){
  const appState = useAppState();
  return <AppContent appState={appState} />;
}

export default App;
