import React from "react";
function TransactionTable({ selectedAccount, fromDate, toDate, setFromDate, setToDate, filteredTransactions, handleDownload, setModalTx, setShowTxModal, onStatementOverMail }) {
  const [txSearch, setTxSearch] = React.useState("");
  const [downloadType, setDownloadType] = React.useState("pdf");
  const [currentPage, setCurrentPage] = React.useState(1);
  const [pageInput, setPageInput] = React.useState("");
  const PAGE_SIZE = 10;

  
  const visibleTransactions = filteredTransactions().filter(t => t.description.toLowerCase().includes(txSearch.toLowerCase()));

  const totalPages = Math.max(1, Math.ceil(visibleTransactions.length / PAGE_SIZE));
  const page = Math.min(currentPage, totalPages);
  const startIndex = (page - 1) * PAGE_SIZE;
  const pagedTransactions = visibleTransactions.slice(startIndex, startIndex + PAGE_SIZE);

  const goToPage = () => {
    if (!pageInput) return;
    const num = parseInt(pageInput, 10);
    if (!isNaN(num)) {
      const clamped = Math.min(Math.max(num, 1), totalPages);
      setCurrentPage(clamped);
    }
    setPageInput("");
  };
  return (
    <div className="transactions">
      <h2>Transactions</h2>
      {selectedAccount ? (
        <>
          <div className="top-bar" style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '0.5rem' }}>
            <input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} /> to
            <input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} />
            <button onClick={() => { setFromDate(""); setToDate(""); }}>Clear Dates</button>
            <input
              type="text"
              placeholder="Search transactions..."
              value={txSearch}
              onChange={e => setTxSearch(e.target.value)}
              style={{ marginLeft: "1rem" }}
            />
            <button onClick={onStatementOverMail} disabled={!selectedAccount} style={{ marginLeft: 'auto', padding: '0.4rem 0.8rem' }}>Statement Over Mail</button>
          </div>
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Description</th>
                <th>Debit</th>
                <th>Credit</th>
                <th>Balance</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody>
              {pagedTransactions.length > 0 ? (
                pagedTransactions.map((t, index) => (
                  <tr key={index}>
                    <td>{t.date}</td>
                    <td>{t.description}</td>
                    <td style={{ color: t.debit !== "-" ? "green" : undefined }}>{t.debit !== "-" ? `$${t.debit}` : "-"}</td>
                    <td style={{ color: t.credit !== "-" ? "red" : undefined }}>{t.credit !== "-" ? `$${t.credit}` : "-"}</td>
                    <td>{`$${t.balance}`}</td>
                    <td>
                      <button
                        style={{ background: "none", border: "none", cursor: "pointer" }}
                        title="View Details"
                        onClick={() => { setModalTx(t); setShowTxModal(true); }}
                      >
                        <span role="img" aria-label="eye">👁️</span>
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" style={{ color: "gray", fontStyle: "italic" }}>
                    No transactions found for the selected date range.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "1.5rem", flexWrap: "wrap", gap: "0.75rem" }}>
            {/* Left: Download options */}
            <div style={{ display: "flex", alignItems: "center" }}>
              <span style={{ marginRight: "0.5rem" }}>Download statement as</span>
              <select value={downloadType} onChange={e => setDownloadType(e.target.value)} style={{ marginRight: "0.5rem" }}>
                <option value="pdf">PDF file</option>
                <option value="csv">XLS file</option>
              </select>
              <button onClick={() => handleDownload(downloadType)}>OK</button>
            </div>
            {/* Right: Pagination */}
            {visibleTransactions.length > 0 && (
              <div style={{ display: "flex", alignItems: "center", flexWrap: "wrap", justifyContent: "flex-end" }}>
                <div style={{ display: "flex", alignItems: "center", flexWrap: "wrap" }}>
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map(num => (
                    <button
                      key={num}
                      onClick={() => setCurrentPage(num)}
                      style={{
                        marginRight: 4,
                        padding: "4px 8px",
                        border: num === page ? "2px solid #007bff" : "1px solid #ccc",
                        background: num === page ? "#e7f1ff" : "#fff",
                        color: "#000",
                        cursor: "pointer",
                        fontWeight: num === page ? "bold" : "normal"
                      }}
                      title={`Go to page ${num}`}
                    >
                      {num}
                    </button>
                  ))}
                  <span style={{ margin: "0 4px" }}>|</span>
                  <button
                    onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                    disabled={page === 1}
                    style={{ padding: "4px 8px", cursor: page === 1 ? "not-allowed" : "pointer" }}
                  >&lt; Previous</button>
                  <button
                    onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                    disabled={page === totalPages}
                    style={{ padding: "4px 8px", marginLeft: 4, cursor: page === totalPages ? "not-allowed" : "pointer" }}
                  >Next &gt;</button>
                </div>
                <div style={{ display: "flex", alignItems: "center" }}>
                  <input
                    type="number"
                    min={1}
                    max={totalPages}
                    value={pageInput}
                    placeholder="#"
                    onChange={e => setPageInput(e.target.value)}
                    style={{ width: 60, marginLeft: 8, marginRight: 4 }}
                    onKeyDown={e => { if (e.key === 'Enter') { goToPage(); } }}
                  />
                  <button onClick={goToPage}>Go</button>
                  <span style={{ marginLeft: 8, fontSize: "0.85rem", color: "#555" }}>Page {page} of {totalPages}</span>
                </div>
              </div>
            )}
          </div>
        </>
      ) : (
        <p style={{ color: "gray", fontStyle: "italic" }}>
          Select an account to view transactions.
        </p>
      )}
    </div>
  );
}

export default TransactionTable;
