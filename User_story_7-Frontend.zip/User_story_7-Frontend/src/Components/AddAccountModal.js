import React, { useState } from "react";

function AddAccountModal({ onAddAccount, onClose }) {
  const [formData, setFormData] = useState({
    name: "",
    number: "",
    type: "Savings",
    currency: "USD",
    balance: ""
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.name && formData.number && formData.balance) {
      onAddAccount({
        ...formData,
        balance: parseFloat(formData.balance),
        status: "Active",
        bankingSegment: "Personal Banking"
      });
      onClose();
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h3>Add Bank Account</h3>
        <form onSubmit={handleSubmit} className="modal-form">
          <input
            type="text"
            name="name"
            placeholder="Account Name"
            value={formData.name}
            onChange={handleChange}
          />
          <input
            type="text"
            name="number"
            placeholder="Account Number"
            value={formData.number}
            onChange={handleChange}
          />
          <select
            name="type"
            value={formData.type}
            onChange={handleChange}
          >
            <option value="Savings">Savings</option>
            <option value="Checking">Checking</option>
          </select>
          <select
            name="currency"
            value={formData.currency}
            onChange={handleChange}
          >
            <option value="USD">USD</option>
            <option value="INR">INR</option>
            <option value="EUR">EUR</option>
          </select>
          <input
            type="number"
            name="balance"
            placeholder="Balance"
            value={formData.balance}
            onChange={handleChange}
          />
          <div className="modal-actions">
            <button type="submit">Add</button>
            <button type="button" onClick={onClose}>
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default AddAccountModal;

