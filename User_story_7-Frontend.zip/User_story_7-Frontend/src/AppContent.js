import "./MainApp.css";
import Header from "./Components/Header";
import AccountTable from "./Components/AccountTable";
import TransactionTable from "./Components/TransactionTable";
import StatementOverMail from "./Components/StatementOverMail";
import TransactionModal from "./Components/TransactionModal";
import AddAccountModal from "./Components/AddAccountModal";

import { usersData, exchangeRates } from "./Components/data";
import { handleDownload } from "./utils/downloadUtils";
// App state is now passed from App (so routing can share it)

function AppContent({ appState }) {
  const {
    selectedAccount, setSelectedAccount,
    search, setSearch,
    bankingType, setBankingType,
    showTxModal, setShowTxModal,
    modalTx, setModalTx,
    currency, setCurrency,
    currentUser, setCurrentUser,
    switchUser,
    fromDate, toDate, setFromDate, setToDate,
    filteredTransactions, filteredAccounts,

    // ✅ already inside your hook
  showAddModal, setShowAddModal,
  showStatementMailPage, setShowStatementMailPage,
  statementMailContext, setStatementMailContext,
  } = appState;

  // 🔑 Function to add new account directly to currentUser
  const handleAddAccount = (newAcc) => {
    setCurrentUser({
      ...currentUser,
      accounts: [...currentUser.accounts, newAcc],
    });
    setShowAddModal(false);
  };

  return (
    <div className="app">
      <Header
        bankingType={bankingType}
        setBankingType={setBankingType}
        search={search}
        setSearch={setSearch}
        currentUser={currentUser}
        usersData={usersData}
        switchUser={switchUser}
        setSelectedAccount={setSelectedAccount}
        setShowTxModal={setShowTxModal}
      />

      {/* Better to keep Add button near Account Table */}
      <AccountTable
        filteredAccounts={filteredAccounts}
        exchangeRates={exchangeRates}
        currency={currency}
        setCurrency={setCurrency}
        setSelectedAccount={setSelectedAccount}
        onAddAccountClick={() => setShowAddModal(true)} // ✅ use global state
      />

      {showStatementMailPage ? (
        <StatementOverMail
          ctx={statementMailContext}
          onBack={() => setShowStatementMailPage(false)}
          onSubmit={(payload) => { console.log('Statement request', payload); alert('Statement request submitted'); setShowStatementMailPage(false); }}
        />
      ) : (
        <TransactionTable
          selectedAccount={selectedAccount}
          fromDate={fromDate}
          toDate={toDate}
          setFromDate={setFromDate}
          setToDate={setToDate}
          filteredTransactions={filteredTransactions}
          handleDownload={(type) => handleDownload(type, filteredTransactions)}
          setModalTx={setModalTx}
          setShowTxModal={setShowTxModal}
          onStatementOverMail={() => {
            if (!selectedAccount) return;
            setStatementMailContext({
              account: selectedAccount,
              fromDate,
              toDate,
              email: currentUser?.email || ''
            });
            setShowStatementMailPage(true);
          }}
        />
      )}

      {showTxModal && modalTx && (
        <TransactionModal modalTx={modalTx} setShowTxModal={setShowTxModal} />
      )}

      {showAddModal && (
        <AddAccountModal
          onAddAccount={handleAddAccount}
          onClose={() => setShowAddModal(false)}
        />
      )}
    </div>
  );
}

export default AppContent;
